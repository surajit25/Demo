from django.contrib import admin
from storeapp.models.carddata import Card

# Register your models here.

admin.site.register(Card)