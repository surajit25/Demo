from django.apps import AppConfig


class StoreappConfig(AppConfig):
    name = 'storeapp'
