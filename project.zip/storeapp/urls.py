from django.contrib import admin
from django.urls import path

from storeapp import views

urlpatterns = [
    path('',views.demo),
]