from django.db import models

class Card(models.Model):
    name=models.CharField(max_length=20,default='')
    image=models.ImageField(upload_to='pics',default='')
    description=models.TextField(max_length=100,default='')